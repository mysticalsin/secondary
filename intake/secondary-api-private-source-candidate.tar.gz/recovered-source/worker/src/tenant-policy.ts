// TenantPolicy: one Durable Object per tenant (SQLite). It owns who a person is inside the tenant:
// principals, role assignments, memberships, named NDA grants, time-boxed elevations, the
// revocation epoch and the per-principal request counter. It holds no organisation content.

import { DurableObject } from "cloudflare:workers";
import { ROLE_ORDER, ROLES, type ScopeType } from "@secondary/policy";
import { GOV_METHODS, GovStore } from "./admin/store.ts";
import {
  type EntraSubject,
  type GroupOp,
  IdentityStore,
  principalIdFor,
  type UserChange,
} from "./auth/identity-store.ts";
import { exportTables, replaceTables, type Snapshot } from "./ops-snapshot.ts";
import { SecurityJournal } from "./security-journal.ts";
import { allOn, isSwitchName, SWITCHES, type SwitchName, type SwitchState } from "./switches.ts";

export type Membership = { scope_type: ScopeType; scope_id: string };
export type TenantConfig = { tenantId: string; seed: number; personalOwners: string[] };
export type SeedPrincipal = {
  id: string;
  email: string;
  roleIds: string[];
  memberships: Membership[];
};
export type ActAs = { id: string; roleIds: string[]; memberships: Membership[] };
export type SessionInput = {
  email: string;
  actAs: ActAs | null;
  now: number;
  limit: number;
  /** Which identity source signed the request in. */
  via?: "entra" | "access" | "internal";
  /** A directory (SCIM) manages this tenant: an unknown principal is not active (H-02). */
  managed?: boolean;
  /** This email is explicitly linked to its Access identity (ACCESS_LINKED_EMAILS). */
  accessLinked?: boolean;
};
export type Session = {
  limited: boolean;
  /** Seconds until the request window resets (set when limited). */
  retryAfter: number;
  principal: { id: string; email: string; roleIds: string[]; memberships: Membership[] };
  ndaGrants: string[];
  /** Node ids opened to Everyone at Mantu (reader or contributor). The engine lifts reading only. */
  openBrains: string[];
  elevatedUntil: number | null;
  epoch: number;
  config: TenantConfig | null;
  switches: SwitchState;
  /** False once the directory (SCIM) has deprovisioned the principal: the API refuses every source of identity. */
  active: boolean;
  /** Changes whenever a role is edited. The API refetches the role table only when it moves. */
  rolesVersion: number;
};

const WINDOW_MS = 60_000;
const MAX_ELEVATION_HOURS = 24;
/** A first approval waits this long for the second person. */
const SECOND_PERSON_TTL_MS = 24 * 3_600_000;
/** Tables that make up a TenantPolicy snapshot. The request counter is not part of it. */
const SNAPSHOT_TABLES = [
  "config",
  "principals",
  "role_assignments",
  "memberships",
  "nda_grants",
  "elevations",
  "revocation",
  "switches",
  "pending_ops",
  "principal_status",
  "group_role_map",
  "scim_users",
  "scim_groups",
  "scim_group_members",
  "gov_meta",
  "gov_roles",
  "gov_role_history",
  "gov_changes",
  "gov_elevations",
  "gov_access_requests",
  "gov_identity",
  "gov_notifications",
  "pilot_cohorts",
  "open_brains",
] as const;

/** Features a pilot cohort can switch on. A key no cohort mentions is on for everyone. */
export const FLAG_KEYS = ["brains_v3", "imports", "coach", "batch_review", "journal"] as const;
export type FlagKey = (typeof FLAG_KEYS)[number];
export type Cohort = {
  id: string;
  name: string;
  members: string[];
  flags: Record<string, boolean>;
  createdAt: number;
};
export type AgentRow = {
  grantId: string;
  clientId: string;
  host: string;
  scopes: string[];
  firstAt: number;
  lastAt: number;
  lastTool: string;
  calls: number;
  revoked: boolean;
};
const MAX_COHORTS = 20;
const MAX_COHORT_MEMBERS = 500;
const MAX_GRANTS_PER_PERSON = 50;

export class TenantPolicy extends DurableObject<Env> {
  private readonly sql: SqlStorage;
  private readonly identity: IdentityStore;
  private readonly journal: SecurityJournal;
  private govStore!: GovStore;

  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    this.sql = ctx.storage.sql;
    this.journal = new SecurityJournal(this.sql);
    this.identity = new IdentityStore(this.sql, ctx.storage, () => this.bump(), this.journal);
    ctx.blockConcurrencyWhile(async () => {
      this.sql.exec(`
        CREATE TABLE IF NOT EXISTS config (k TEXT PRIMARY KEY, v TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS principals (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS role_assignments (
          principal_id TEXT NOT NULL, role_id TEXT NOT NULL, PRIMARY KEY (principal_id, role_id));
        CREATE TABLE IF NOT EXISTS memberships (
          principal_id TEXT NOT NULL, scope_type TEXT NOT NULL, scope_id TEXT NOT NULL,
          PRIMARY KEY (principal_id, scope_type, scope_id));
        CREATE TABLE IF NOT EXISTS nda_grants (
          principal_id TEXT NOT NULL, account_id TEXT NOT NULL, PRIMARY KEY (principal_id, account_id));
        CREATE TABLE IF NOT EXISTS elevations (
          id INTEGER PRIMARY KEY AUTOINCREMENT, principal_id TEXT NOT NULL,
          until INTEGER NOT NULL, reason TEXT NOT NULL, created_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS revocation (id INTEGER PRIMARY KEY CHECK (id = 1), epoch INTEGER NOT NULL);
        INSERT OR IGNORE INTO revocation (id, epoch) VALUES (1, 0);
        CREATE TABLE IF NOT EXISTS rate (
          principal_id TEXT PRIMARY KEY, window INTEGER NOT NULL, count INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS switches (
          name TEXT PRIMARY KEY, enabled INTEGER NOT NULL, changed_by TEXT NOT NULL, changed_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS pending_ops (
          key TEXT PRIMARY KEY, requested_by TEXT NOT NULL, requested_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS nonces (key TEXT PRIMARY KEY, expires_at INTEGER NOT NULL);
        -- Not in SNAPSHOT_TABLES on purpose: a restore replaces the listed tables only, so this list
        -- survives it and is applied again afterwards (M-03). It is never exported or backed up.
        -- Everyone at Mantu per brain node (the one place the engine reads it from). In SNAPSHOT_TABLES:
        -- it is tenant security state, and a restore must not leave a brain wider or narrower than saved.
        CREATE TABLE IF NOT EXISTS open_brains (
          node_id TEXT PRIMARY KEY, level TEXT NOT NULL CHECK (level IN ('reader', 'contributor')));
        CREATE TABLE IF NOT EXISTS pilot_cohorts (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, members TEXT NOT NULL, flags TEXT NOT NULL,
          created_at INTEGER NOT NULL);
        -- Agent connections (one row per OAuth grant that called). Not in SNAPSHOT_TABLES on purpose:
        -- a restore must never bring back a connection that was revoked. Content-free: ids, host, scopes.
        CREATE TABLE IF NOT EXISTS agent_grants (
          principal_id TEXT NOT NULL, grant_id TEXT NOT NULL, client_id TEXT NOT NULL, host TEXT NOT NULL,
          scopes TEXT NOT NULL, first_at INTEGER NOT NULL, last_at INTEGER NOT NULL,
          last_tool TEXT NOT NULL, calls INTEGER NOT NULL, revoked_at INTEGER,
          PRIMARY KEY (principal_id, grant_id));
        CREATE TABLE IF NOT EXISTS erasure_tombstones (
          principal_id TEXT PRIMARY KEY, pseudonym TEXT NOT NULL, aliases TEXT NOT NULL,
          erased_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
      `);
      this.journal.init();
      this.identity.init();
      // Governance console state (roles as data, changes, elevations, requests, inbox).
      this.govStore = new GovStore(
        {
          sql: this.sql,
          tx: (fn) => ctx.storage.transactionSync(fn),
          bump: () => this.bump(),
          journal: this.journal,
        },
        ROLE_ORDER.map((r) => ROLES[r]),
      );
    });
  }

  /** Single entry point for admin/store.ts, so this class stays small. Typed by admin/client.ts. */
  gov(method: string, args: unknown[]): unknown {
    if (!(GOV_METHODS as readonly string[]).includes(method))
      return {
        ok: false,
        code: "unknown_gov_method",
        message: "Not a governance method",
        status: 400,
      };
    const fn = (this.govStore as unknown as Record<string, (...a: unknown[]) => unknown>)[method];
    return (fn as (...a: unknown[]) => unknown).apply(this.govStore, args);
  }

  private bump(): number {
    return this.sql
      .exec("UPDATE revocation SET epoch = epoch + 1 WHERE id = 1 RETURNING epoch")
      .one().epoch as number;
  }

  epoch(): number {
    return this.sql.exec("SELECT epoch FROM revocation WHERE id = 1").one().epoch as number;
  }

  getConfig(): TenantConfig | null {
    const row = this.sql.exec("SELECT v FROM config WHERE k = 'tenant'").toArray()[0];
    return row ? (JSON.parse(row.v as string) as TenantConfig) : null;
  }

  /** Replace the tenant's directory. Dev seed only. Resets grants, elevations and counters. */
  seed(config: TenantConfig, principals: SeedPrincipal[], now: number = Date.now()): number {
    this.ctx.storage.transactionSync(() => {
      for (const t of [
        "principals",
        "role_assignments",
        "memberships",
        "nda_grants",
        "elevations",
        "rate",
        "erasure_tombstones",
        "open_brains",
      ])
        this.sql.exec(`DELETE FROM ${t}`);
      this.govStore.reset(now);
      this.journal.clear();
      // The workspaces are emptied by a reseed, so the wiki seed starts over too.
      this.sql.exec("DELETE FROM config WHERE k IN ('seed_version', 'seed_claim')");
      this.sql.exec(
        "INSERT INTO config (k, v) VALUES ('tenant', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
        JSON.stringify(config),
      );
      this.sql.exec(
        "INSERT INTO config (k, v) VALUES ('seeded_at', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
        String(now),
      );
      for (const p of principals) {
        this.sql.exec(
          "INSERT INTO principals (id, email) VALUES (?, ?)",
          p.id,
          p.email.toLowerCase(),
        );
        for (const r of p.roleIds)
          this.sql.exec(
            "INSERT INTO role_assignments (principal_id, role_id) VALUES (?, ?)",
            p.id,
            r,
          );
        for (const m of p.memberships)
          this.sql.exec(
            "INSERT INTO memberships (principal_id, scope_type, scope_id) VALUES (?, ?, ?)",
            p.id,
            m.scope_type,
            m.scope_id,
          );
      }
    });
    return this.bump();
  }

  /**
   * Dev auto-seed guard: seed only when no `seeded_at` row exists, so concurrent first requests seed once.
   * Returns the new epoch, or null when the tenant was already seeded.
   */
  seedOnce(config: TenantConfig, principals: SeedPrincipal[], now: number): number | null {
    const done = this.sql.exec("SELECT 1 FROM config WHERE k = 'seeded_at'").toArray().length > 0;
    return done ? null : this.seed(config, principals, now);
  }

  /** The version of the dev wiki seed this tenant has completed (0 when none). */
  seedVersion(): number {
    const r = this.sql.exec("SELECT v FROM config WHERE k = 'seed_version'").toArray()[0];
    return r ? Number(r.v) || 0 : 0;
  }

  /**
   * Dev wiki seed: take the right to run version `version`. False when that version (or a newer one)
   * is done, or another request holds an unexpired claim, so concurrent requests seed once. A claim
   * that never completes expires after `leaseMs` and the next request tries again.
   */
  seedClaim(version: number, now: number, leaseMs = 120_000): boolean {
    if (this.seedVersion() >= version) return false;
    const r = this.sql.exec("SELECT v FROM config WHERE k = 'seed_claim'").toArray()[0];
    if (r) {
      const c = JSON.parse(r.v as string) as { version: number; at: number };
      if (c.version >= version && now - c.at < leaseMs) return false;
    }
    this.sql.exec(
      "INSERT INTO config (k, v) VALUES ('seed_claim', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
      JSON.stringify({ version, at: now }),
    );
    return true;
  }

  /** The claimed version finished: later requests skip it. */
  seedDone(version: number): void {
    this.sql.exec(
      "INSERT INTO config (k, v) VALUES ('seed_version', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
      String(version),
    );
    this.sql.exec("DELETE FROM config WHERE k = 'seed_claim'");
  }

  /**
   * Resolve the caller for one request: identity, roles, grants, elevation and the request counter.
   * `actAs` (dev personas only, decided by the API) replaces stored roles and memberships.
   */
  async session(input: SessionInput): Promise<Session> {
    const email = input.email.trim().toLowerCase();
    const row = this.sql.exec("SELECT id FROM principals WHERE email = ?", email).toArray()[0];
    const identityId = (row?.id as string | undefined) ?? (await principalIdFor(email));

    const window = Math.floor(input.now / WINDOW_MS);
    const count = this.sql
      .exec(
        `INSERT INTO rate (principal_id, window, count) VALUES (?, ?, 1)
         ON CONFLICT(principal_id) DO UPDATE SET
           window = excluded.window,
           count = CASE WHEN rate.window = excluded.window THEN rate.count + 1 ELSE 1 END
         RETURNING count`,
        identityId,
        window,
      )
      .one().count as number;

    let id = identityId;
    let roleIds: string[] = [];
    let memberships: Membership[] = [];
    if (input.actAs) {
      ({ id, roleIds, memberships } = input.actAs);
      // Memberships granted through the console add to the persona's own (dev only).
      const stored = this.sql
        .exec("SELECT scope_type, scope_id FROM memberships WHERE principal_id = ?", id)
        .toArray()
        .map((r) => ({ scope_type: r.scope_type as ScopeType, scope_id: r.scope_id as string }));
      memberships = [
        ...memberships,
        ...stored.filter(
          (m) =>
            !memberships.some((x) => x.scope_type === m.scope_type && x.scope_id === m.scope_id),
        ),
      ];
    } else if (row) {
      roleIds = this.sql
        .exec("SELECT role_id FROM role_assignments WHERE principal_id = ? ORDER BY role_id", id)
        .toArray()
        .map((r) => r.role_id as string);
      roleIds = [...new Set([...roleIds, ...this.identity.mappedRoles(id)])].sort();
      memberships = this.sql
        .exec(
          "SELECT scope_type, scope_id FROM memberships WHERE principal_id = ? ORDER BY 1, 2",
          id,
        )
        .toArray()
        .map((r) => ({ scope_type: r.scope_type as ScopeType, scope_id: r.scope_id as string }));
    }
    // Grants and elevations load only for a principal that exists (M-10): a renamed or unknown email
    // falls back to a derived id and must not inherit what an earlier holder of that id was given.
    const known = !!row || !!input.actAs;
    const ndaGrants = known
      ? this.sql
          .exec(
            "SELECT account_id FROM nda_grants WHERE principal_id = ? AND (expires_at IS NULL OR expires_at > ?) ORDER BY 1",
            id,
            input.now,
          )
          .toArray()
          .map((r) => r.account_id as string)
      : [];
    const until = known
      ? (this.sql
          .exec(
            "SELECT MAX(until) AS u FROM elevations WHERE principal_id = ? AND until > ?",
            id,
            input.now,
          )
          .one().u as number | null)
      : null;
    // H-01: an Entra-bound principal is not reachable through another identity source by email alone.
    const hijack =
      !input.actAs &&
      input.via !== undefined &&
      input.via !== "entra" &&
      !input.accessLinked &&
      this.identity.subjectOfEmail(email) !== null;

    return {
      limited: count > input.limit,
      retryAfter: Math.max(1, Math.ceil(((window + 1) * WINDOW_MS - input.now) / 1000)),
      principal: { id, email, roleIds, memberships },
      ndaGrants,
      openBrains: this.sql
        .exec("SELECT node_id FROM open_brains ORDER BY 1")
        .toArray()
        .map((r) => r.node_id as string),
      elevatedUntil: until,
      epoch: this.epoch(),
      config: this.getConfig(),
      switches: this.switchState(),
      active: !hijack && this.identity.isEmailActive(email, input.managed === true),
      rolesVersion: this.govStore.rolesVersion(),
    };
  }

  // ---- agent connections (docs/API-CONTRACT.md "Agent connections") ----

  /**
   * Record one MCP call by grant, or learn that the grant was revoked. A revoked grant is never
   * updated again and the caller must refuse the call. Ids, host, scopes and the tool name only.
   */
  agentSeen(a: {
    principalId: string;
    grantId: string;
    clientId: string;
    host: string;
    scopes: string[];
    tool: string;
    now: number;
  }): { revoked: boolean } {
    const row = this.sql
      .exec(
        "SELECT revoked_at FROM agent_grants WHERE principal_id = ? AND grant_id = ?",
        a.principalId,
        a.grantId,
      )
      .toArray()[0];
    if (row?.revoked_at != null) return { revoked: true };
    this.sql.exec(
      `INSERT INTO agent_grants (principal_id, grant_id, client_id, host, scopes, first_at, last_at, last_tool, calls)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
       ON CONFLICT(principal_id, grant_id) DO UPDATE SET last_at = excluded.last_at,
         last_tool = excluded.last_tool, scopes = excluded.scopes, host = excluded.host, calls = calls + 1`,
      a.principalId,
      a.grantId,
      a.clientId,
      a.host,
      JSON.stringify(a.scopes.slice(0, 10)),
      a.now,
      a.now,
      a.tool.slice(0, 60),
    );
    // Keep the newest rows only; a revoked one is kept as long as it is among them.
    this.sql.exec(
      `DELETE FROM agent_grants WHERE principal_id = ? AND grant_id NOT IN
         (SELECT grant_id FROM agent_grants WHERE principal_id = ? ORDER BY last_at DESC LIMIT ?)`,
      a.principalId,
      a.principalId,
      MAX_GRANTS_PER_PERSON,
    );
    return { revoked: false };
  }

  agentList(principalId: string): AgentRow[] {
    return this.sql
      .exec("SELECT * FROM agent_grants WHERE principal_id = ? ORDER BY last_at DESC", principalId)
      .toArray()
      .map((r) => ({
        grantId: r.grant_id as string,
        clientId: r.client_id as string,
        host: r.host as string,
        scopes: JSON.parse(r.scopes as string) as string[],
        firstAt: r.first_at as number,
        lastAt: r.last_at as number,
        lastTool: r.last_tool as string,
        calls: r.calls as number,
        revoked: r.revoked_at != null,
      }));
  }

  /** Revoke the caller's own grants, one by id or every grant of a host. Returns the grants revoked. */
  agentRevoke(
    principalId: string,
    by: { grantId: string } | { host: string } | { all: true },
    now: number,
  ): { grantId: string; clientId: string }[] {
    const hit =
      "all" in by
        ? this.sql
            .exec(
              "UPDATE agent_grants SET revoked_at = ? WHERE principal_id = ? AND revoked_at IS NULL RETURNING grant_id, client_id",
              now,
              principalId,
            )
            .toArray()
        : "grantId" in by
          ? this.sql
              .exec(
                "UPDATE agent_grants SET revoked_at = ? WHERE principal_id = ? AND grant_id = ? AND revoked_at IS NULL RETURNING grant_id, client_id",
                now,
                principalId,
                by.grantId,
              )
              .toArray()
          : this.sql
              .exec(
                "UPDATE agent_grants SET revoked_at = ? WHERE principal_id = ? AND host = ? AND revoked_at IS NULL RETURNING grant_id, client_id",
                now,
                principalId,
                by.host,
              )
              .toArray();
    return hit.map((r) => ({ grantId: r.grant_id as string, clientId: r.client_id as string }));
  }

  // ---- Everyone at Mantu (brain access) ----

  /** Open a brain node to Everyone at Mantu, or close it ("none"). The API has bounded it by type. */
  openBrainSet(nodeId: string, level: "none" | "reader" | "contributor"): void {
    if (level === "none") this.sql.exec("DELETE FROM open_brains WHERE node_id = ?", nodeId);
    else
      this.sql.exec(
        "INSERT INTO open_brains (node_id, level) VALUES (?, ?) ON CONFLICT(node_id) DO UPDATE SET level = excluded.level",
        nodeId,
        level,
      );
    // Sessions and views are rebuilt from the table on every request; the epoch keeps caches honest.
    this.bump();
  }

  // ---- pilot cohorts ----

  pilotList(): Cohort[] {
    return this.sql
      .exec("SELECT * FROM pilot_cohorts ORDER BY created_at, id")
      .toArray()
      .map((r) => ({
        id: r.id as string,
        name: r.name as string,
        members: JSON.parse(r.members as string) as string[],
        flags: JSON.parse(r.flags as string) as Record<string, boolean>,
        createdAt: r.created_at as number,
      }));
  }

  pilotSave(
    c: { id: string; name: string; members: string[]; flags: Record<string, boolean> },
    create: boolean,
    now: number,
  ): "ok" | "not_found" | "too_many" {
    const exists =
      this.sql.exec("SELECT 1 FROM pilot_cohorts WHERE id = ?", c.id).toArray().length > 0;
    if (
      create &&
      (this.sql.exec("SELECT COUNT(*) AS n FROM pilot_cohorts").one().n as number) >= MAX_COHORTS
    )
      return "too_many";
    if (!create && !exists) return "not_found";
    const members = [...new Set(c.members.map((m) => m.trim().toLowerCase()))].slice(
      0,
      MAX_COHORT_MEMBERS,
    );
    this.sql.exec(
      `INSERT INTO pilot_cohorts (id, name, members, flags, created_at) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET name = excluded.name, members = excluded.members, flags = excluded.flags`,
      c.id,
      c.name,
      JSON.stringify(members),
      JSON.stringify(c.flags),
      now,
    );
    return "ok";
  }

  pilotDelete(id: string): boolean {
    return (
      this.sql.exec("DELETE FROM pilot_cohorts WHERE id = ? RETURNING 1", id).toArray().length > 0
    );
  }

  /** A person's name leaves every invite list (erasure). */
  private pilotForget(email: string): void {
    for (const c of this.pilotList())
      if (c.members.includes(email))
        this.sql.exec(
          "UPDATE pilot_cohorts SET members = ? WHERE id = ?",
          JSON.stringify(c.members.filter((m) => m !== email)),
          c.id,
        );
  }

  /** Flags for one address: a key is managed once any cohort sets it, and is then on only for its members. */
  flagsFor(email: string): Record<FlagKey, boolean> {
    const e = email.trim().toLowerCase();
    const cohorts = this.pilotList();
    const out = {} as Record<FlagKey, boolean>;
    for (const k of FLAG_KEYS) {
      const setBy = cohorts.filter((c) => Object.hasOwn(c.flags, k));
      out[k] =
        setBy.length === 0 || setBy.some((c) => c.flags[k] === true && c.members.includes(e));
    }
    return out;
  }

  /**
   * Replay cache for the signed service calls. True the first time a key is seen inside its TTL,
   * false for a replay. Expired keys are dropped on every call, so the table holds about two minutes.
   */
  nonceFirst(key: string, now: number, ttlMs: number): boolean {
    this.sql.exec("DELETE FROM nonces WHERE expires_at <= ?", now);
    return (
      this.sql
        .exec(
          "INSERT OR IGNORE INTO nonces (key, expires_at) VALUES (?, ?) RETURNING key",
          key,
          now + ttlMs,
        )
        .toArray().length === 1
    );
  }

  /** Fixed one-minute window counter for sensitive low-volume routes such as seeding. */
  hit(key: string, now: number, limit: number): { limited: boolean; retryAfter: number } {
    const window = Math.floor(now / WINDOW_MS);
    const count = this.sql
      .exec(
        `INSERT INTO rate (principal_id, window, count) VALUES (?, ?, 1)
         ON CONFLICT(principal_id) DO UPDATE SET
           window = excluded.window,
           count = CASE WHEN rate.window = excluded.window THEN rate.count + 1 ELSE 1 END
         RETURNING count`,
        key,
        window,
      )
      .one().count as number;
    return {
      limited: count > limit,
      retryAfter: Math.max(1, Math.ceil(((window + 1) * WINDOW_MS - now) / 1000)),
    };
  }

  /** Members per role, for the admin role list. */
  roleCounts(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const r of this.sql
      .exec("SELECT role_id, COUNT(*) AS n FROM role_assignments GROUP BY role_id")
      .toArray())
      out[r.role_id as string] = r.n as number;
    return out;
  }

  // ---- directory changes: each one bumps the revocation epoch ----

  setRoles(principalId: string, roleIds: string[]): number {
    this.ctx.storage.transactionSync(() => {
      this.sql.exec("DELETE FROM role_assignments WHERE principal_id = ?", principalId);
      for (const r of roleIds)
        this.sql.exec(
          "INSERT INTO role_assignments (principal_id, role_id) VALUES (?, ?)",
          principalId,
          r,
        );
      this.journal.roles(principalId, roleIds, Date.now());
    });
    return this.bump();
  }

  addMembership(principalId: string, m: Membership): number {
    this.sql.exec(
      "INSERT OR IGNORE INTO memberships (principal_id, scope_type, scope_id) VALUES (?, ?, ?)",
      principalId,
      m.scope_type,
      m.scope_id,
    );
    this.journal.member(principalId, m.scope_type, m.scope_id, true, Date.now());
    return this.bump();
  }

  grantNda(principalId: string, accountId: string): number {
    this.sql.exec(
      "INSERT OR IGNORE INTO nda_grants (principal_id, account_id) VALUES (?, ?)",
      principalId,
      accountId,
    );
    this.journal.nda(principalId, accountId, true, Date.now());
    return this.bump();
  }

  revokeNda(principalId: string, accountId: string): number {
    this.sql.exec(
      "DELETE FROM nda_grants WHERE principal_id = ? AND account_id = ?",
      principalId,
      accountId,
    );
    this.journal.nda(principalId, accountId, false, Date.now());
    return this.bump();
  }

  /** Time-boxed elevation with a stated reason. Capped at 24 hours; the policy engine applies the role's own limit. */
  elevate(principalId: string, hours: number, reason: string, now: number): number | null {
    if (!reason.trim()) return null; // an elevation without a stated reason is refused
    const h = Math.min(Math.max(hours, 0), MAX_ELEVATION_HOURS);
    this.sql.exec(
      "INSERT INTO elevations (principal_id, until, reason, created_at) VALUES (?, ?, ?, ?)",
      principalId,
      now + h * 3_600_000,
      reason.slice(0, 200),
      now,
    );
    return this.bump();
  }

  /** Remove every role, membership, NDA grant and elevation of a principal. */
  revokeAll(principalId: string): number {
    this.ctx.storage.transactionSync(() => {
      for (const t of ["role_assignments", "memberships", "nda_grants", "elevations"])
        this.sql.exec(`DELETE FROM ${t} WHERE principal_id = ?`, principalId);
      this.journal.revokeAll(principalId, Date.now());
    });
    return this.bump();
  }

  // ---- operations: kill switches, two-person steps, snapshots, rights ----

  private switchState(): SwitchState {
    const out = allOn();
    for (const r of this.sql.exec("SELECT name, enabled FROM switches").toArray())
      if (isSwitchName(r.name)) out[r.name] = r.enabled === 1;
    return out;
  }

  /** Current state with who changed it and when, plus the re-enable requests waiting for a second person. */
  switchStatus(now: number): {
    switches: Record<SwitchName, { enabled: boolean; changedAt: number | null }>;
    pending: { switch: SwitchName; requestedAt: number }[];
  } {
    const state = this.switchState();
    const at = new Map(
      this.sql
        .exec("SELECT name, changed_at FROM switches")
        .toArray()
        .map((r) => [r.name as string, r.changed_at as number]),
    );
    const switches = Object.fromEntries(
      SWITCHES.map((n) => [n, { enabled: state[n], changedAt: at.get(n) ?? null }]),
    ) as Record<SwitchName, { enabled: boolean; changedAt: number | null }>;
    const pending = this.sql
      .exec(
        "SELECT key, requested_at FROM pending_ops WHERE key LIKE 'switch:%' AND requested_at > ?",
        now - SECOND_PERSON_TTL_MS,
      )
      .toArray()
      .map((r) => ({
        switch: (r.key as string).slice(7) as SwitchName,
        requestedAt: r.requested_at as number,
      }));
    return { switches, pending };
  }

  /**
   * Turning a switch off is always one person. Turning it back on needs a second, different person
   * when `twoPerson` is set (prod): the first request is recorded and expires after 24 hours.
   */
  setSwitch(
    name: SwitchName,
    enabled: boolean,
    actor: string,
    now: number,
    twoPerson: boolean,
    email = "",
  ): { status: "applied" | "pending"; sameActor?: boolean } {
    const apply = () => {
      this.sql.exec(
        `INSERT INTO switches (name, enabled, changed_by, changed_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(name) DO UPDATE SET enabled = excluded.enabled, changed_by = excluded.changed_by,
           changed_at = excluded.changed_at`,
        name,
        enabled ? 1 : 0,
        actor,
        now,
      );
      // Kept outside the snapshot, so a restore cannot turn a kill switch back on (N-02).
      this.journal.switchSet(name, enabled, now);
    };
    if (!enabled) {
      apply();
      this.sql.exec("DELETE FROM pending_ops WHERE key = ?", `switch:${name}`);
      return { status: "applied" };
    }
    if (this.switchState()[name]) return { status: "applied" };
    if (twoPerson) {
      const r = this.requestSecond(`switch:${name}`, actor, now, email);
      if (r !== "second") return { status: "pending", sameActor: r === "same" };
    }
    apply();
    return { status: "applied" };
  }

  /**
   * Two-person rule. "first": recorded. "same": the same person asked again, nothing changes.
   * "second": a different person confirmed within 24 hours, so the caller may proceed.
   * "Same" is decided on the stable identity (N-01): one human under two principal ids is one person.
   * `email` is the address the actor is signed in with; pass it so the identity can be matched.
   */
  requestSecond(key: string, actor: string, now: number, email = ""): "first" | "same" | "second" {
    this.rememberAddress(actor, email);
    const row = this.sql
      .exec("SELECT requested_by, requested_at FROM pending_ops WHERE key = ?", key)
      .toArray()[0];
    if (!row || (row.requested_at as number) <= now - SECOND_PERSON_TTL_MS) {
      this.sql.exec(
        `INSERT INTO pending_ops (key, requested_by, requested_at) VALUES (?, ?, ?)
         ON CONFLICT(key) DO UPDATE SET requested_by = excluded.requested_by, requested_at = excluded.requested_at`,
        key,
        actor,
        now,
      );
      return "first";
    }
    if (this.sameHuman(row.requested_by as string, actor)) return "same";
    this.sql.exec("DELETE FROM pending_ops WHERE key = ?", key);
    return "second";
  }

  /** Who asked first for a pending two-person step, or null when none is waiting. */
  pendingRequester(key: string, now: number): string | null {
    const row = this.sql
      .exec("SELECT requested_by, requested_at FROM pending_ops WHERE key = ?", key)
      .toArray()[0];
    return row && (row.requested_at as number) > now - SECOND_PERSON_TTL_MS
      ? (row.requested_by as string)
      : null;
  }

  /** Remember which address a principal id acted with, so one human holding two ids is recognised (N-01). */
  private rememberAddress(principalId: string, email: string): void {
    const e = email.trim().toLowerCase();
    if (!e.includes("@")) return;
    this.sql.exec(
      "INSERT INTO gov_identity (principal_id, email) VALUES (?, ?) ON CONFLICT(principal_id) DO UPDATE SET email = excluded.email",
      principalId,
      e,
    );
  }

  /**
   * The stable identity behind a principal id: the Entra subject (tenant + oid) when the directory
   * has one, else the normalised address it signed in with, else the id itself.
   */
  private humanKey(principalId: string): string {
    const p = this.sql
      .exec("SELECT subject, email FROM principals WHERE id = ?", principalId)
      .toArray()[0];
    const e = (
      (p?.email as string | undefined) ??
      (this.sql
        .exec("SELECT email FROM gov_identity WHERE principal_id = ?", principalId)
        .toArray()[0]?.email as string | undefined)
    )?.toLowerCase();
    const subject =
      (p?.subject as string | null | undefined) ??
      (e
        ? (this.sql.exec("SELECT subject FROM principals WHERE email = ?", e).toArray()[0]
            ?.subject as string | null | undefined)
        : null);
    if (subject) return `sub:${subject}`;
    return e ? `mail:${e}` : `id:${principalId}`;
  }

  private sameHuman(a: string, b: string): boolean {
    return a === b || this.humanKey(a) === this.humanKey(b);
  }

  /** Every principal id of the same human as `principalId`, itself included (N-01). */
  humanIds(principalId: string, email = ""): string[] {
    this.rememberAddress(principalId, email);
    const key = this.humanKey(principalId);
    const ids = new Set([principalId]);
    for (const r of [
      ...this.sql.exec("SELECT id FROM principals").toArray(),
      ...this.sql.exec("SELECT principal_id AS id FROM gov_identity").toArray(),
    ])
      if (this.humanKey(r.id as string) === key) ids.add(r.id as string);
    return [...ids];
  }

  /** Id of the principal behind an email, or the stable anonymous id when the email is not in the directory. */
  async resolvePrincipalId(email: string): Promise<string> {
    const e = email.trim().toLowerCase();
    const row = this.sql.exec("SELECT id FROM principals WHERE email = ?", e).toArray()[0];
    return (row?.id as string | undefined) ?? (await principalIdFor(e));
  }

  /** The address behind a principal id, for erasure (it may be typed into wiki text). */
  emailOfPrincipal(principalId: string): string | null {
    const row = this.sql
      .exec("SELECT email FROM principals WHERE id = ?", principalId)
      .toArray()[0];
    return (row?.email as string | undefined) ?? null;
  }

  listPrincipalIds(): string[] {
    const ids = new Set(
      this.sql
        .exec("SELECT id FROM principals ORDER BY id")
        .toArray()
        .map((r) => r.id as string),
    );
    for (const id of this.getConfig()?.personalOwners ?? []) ids.add(id);
    return [...ids].sort();
  }

  /** Right to erasure for the directory: identity, roles, memberships, grants, elevations, counters. */
  erasePrincipal(principalId: string): number {
    const erasedEmail =
      (this.sql
        .exec("SELECT lower(email) AS e FROM principals WHERE id = ?", principalId)
        .toArray()[0]?.e as string | undefined) ??
      (this.sql
        .exec("SELECT email AS e FROM gov_identity WHERE principal_id = ?", principalId)
        .toArray()[0]?.e as string | undefined);
    this.ctx.storage.transactionSync(() => {
      // Before the principals row goes: the address is looked up through it.
      this.sql.exec(
        "DELETE FROM gov_identity WHERE principal_id = ?1 OR email = (SELECT lower(email) FROM principals WHERE id = ?1)",
        principalId,
      );
      this.sql.exec(
        "DELETE FROM scim_group_members WHERE user_id IN (SELECT id FROM scim_users WHERE principal_id = ?)",
        principalId,
      );
      for (const t of [
        "principal_status",
        "oidc_groups",
        "scim_users",
        "auth_sessions",
        "principals",
        "role_assignments",
        "memberships",
        "nda_grants",
        "elevations",
        "rate",
      ])
        this.sql.exec(
          `DELETE FROM ${t} WHERE ${t === "principals" ? "id" : "principal_id"} = ?`,
          principalId,
        );
      this.sql.exec("DELETE FROM pending_ops WHERE requested_by = ?", principalId);
      this.sql.exec("DELETE FROM agent_grants WHERE principal_id = ?", principalId);
      if (erasedEmail) this.pilotForget(erasedEmail);
      this.journal.forget(principalId);
    });
    return this.bump();
  }

  /**
   * Remember an erasure so a restore can be undone by applying it again. `aliases` are the person's
   * addresses as typed into text. The row lives until the last backup that could hold the person has expired.
   */
  tombstoneAdd(
    principalId: string,
    pseudonym: string,
    aliases: string[],
    now: number,
    expiresAt: number,
  ): void {
    this.sql.exec(
      `INSERT INTO erasure_tombstones (principal_id, pseudonym, aliases, erased_at, expires_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(principal_id) DO UPDATE SET pseudonym = excluded.pseudonym,
         aliases = excluded.aliases, erased_at = excluded.erased_at, expires_at = excluded.expires_at`,
      principalId,
      pseudonym,
      JSON.stringify(aliases),
      now,
      expiresAt,
    );
  }

  tombstoneList(now: number): { principalId: string; pseudonym: string; aliases: string[] }[] {
    return this.sql
      .exec(
        "SELECT principal_id, pseudonym, aliases FROM erasure_tombstones WHERE expires_at > ?",
        now,
      )
      .toArray()
      .map((r) => ({
        principalId: r.principal_id as string,
        pseudonym: r.pseudonym as string,
        aliases: JSON.parse(r.aliases as string) as string[],
      }));
  }

  /** Drops tombstones whose time is up. Returns how many. */
  tombstonePurge(now: number): number {
    return this.sql
      .exec("DELETE FROM erasure_tombstones WHERE expires_at <= ? RETURNING principal_id", now)
      .toArray().length;
  }

  exportAll(): Snapshot {
    return exportTables(this.sql, SNAPSHOT_TABLES);
  }

  /** Replace this tenant's directory from a snapshot and bump the epoch so every session is re-checked. */
  importAll(data: unknown): number {
    // The counter never goes back to a snapshot's lower value (N-02).
    const live = this.epoch();
    const rows = replaceTables(this.ctx.storage, SNAPSHOT_TABLES, data);
    this.sql.exec("INSERT OR IGNORE INTO revocation (id, epoch) VALUES (1, 0)");
    this.sql.exec("UPDATE revocation SET epoch = MAX(epoch, ?) WHERE id = 1", live);
    // Leavers, revoked grants and memberships and kill switches since the snapshot are applied again.
    this.ctx.storage.transactionSync(() => this.journal.replay());
    this.bump();
    return rows;
  }

  // ---- identity: sessions, Entra group map, SCIM (see auth/identity-store.ts) ----

  loginStatePut(
    h: string,
    nonce: string,
    verifier: string,
    returnTo: string | null,
    now: number,
    ipHash = "",
  ) {
    this.identity.loginStatePut(h, nonce, verifier, returnTo, now, ipHash);
  }
  loginStateTake(h: string, now: number) {
    return this.identity.loginStateTake(h, now);
  }
  sessionCreate(
    idHash: string,
    who: EntraSubject,
    groups: string[],
    now: number,
    managed: boolean,
  ) {
    return this.identity.sessionCreate(
      idHash,
      { ...who, email: who.email.trim().toLowerCase() },
      groups,
      now,
      managed,
    );
  }
  sessionValidate(idHash: string, now: number) {
    return this.identity.sessionValidate(idHash, now);
  }
  sessionDelete(idHash: string) {
    this.identity.sessionDelete(idHash);
  }
  sessionCount(principalId: string) {
    return this.identity.sessionCount(principalId);
  }
  groupMapList() {
    return this.identity.groupMapList();
  }
  groupMapSet(groupId: string, roleId: string) {
    return this.identity.groupMapSet(groupId, roleId);
  }
  groupMapDelete(groupId: string) {
    return this.identity.groupMapDelete(groupId);
  }
  scimUserGet(id: string) {
    return this.identity.scimUserGet(id);
  }
  scimUserList(f: { userName?: string; externalId?: string; id?: string }, s: number, c: number) {
    return this.identity.scimUserList(f, s, c);
  }
  scimUserCreate(input: Parameters<IdentityStore["scimUserCreate"]>[0], now: number) {
    return this.identity.scimUserCreate(input, now);
  }
  scimUserPatch(id: string, change: UserChange, now: number) {
    return this.identity.scimUserPatch(id, change, now);
  }
  scimUserDelete(id: string, now: number) {
    return this.identity.scimUserDelete(id, now);
  }
  scimGroupGet(id: string) {
    return this.identity.scimGroupGet(id);
  }
  scimGroupList(f: { displayName?: string; externalId?: string }, s: number, c: number) {
    return this.identity.scimGroupList(f, s, c);
  }
  scimGroupCreate(input: Parameters<IdentityStore["scimGroupCreate"]>[0], now: number) {
    return this.identity.scimGroupCreate(input, now);
  }
  scimGroupApply(id: string, ops: GroupOp[], now: number) {
    return this.identity.scimGroupApply(id, ops, now);
  }
  scimGroupDelete(id: string) {
    return this.identity.scimGroupDelete(id);
  }
}
